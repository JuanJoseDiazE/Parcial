package Parcial;

public class TipoProducto {
    public String carne;
    public String verdura;
    public String lacteo;
    public String fruta;
    public String pan;
    public String licor;
    public String granos;
    public String aseo;




}

