package Parcial;

import java.util.ArrayList;
import java.util.List;

public class Mercado {
    public byte capacidad;
    private String supermercado;
    private List<Producto>productos;


    public Mercado(byte capacidad) {
        this.capacidad = capacidad;
        this.productos = new ArrayList<Producto>();
    }

    public boolean buscar(String nombre, int codigo,){
        if ((
        ))
    }

    public boolean Agregar(byte capacidad, double cantidadAAgregar){
        if ((productos + cantidadAAgregar) <= capacidad ){
             += cantidadAAgregar;
            return true;
        }else{
            return false;
        }
    }


    public String getSupermercado() {
        return supermercado;
    }

    public void setSupermercado(String supermercado) {
        this.supermercado = supermercado;
    }
}
