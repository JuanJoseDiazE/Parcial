package App;

import Parcial.Mercado;
import Parcial.Producto;
import Parcial.TipoProducto;

public class AppMercado {
    public static void main(String[] args) {

        TipoProducto tipoProducto = new TipoProducto();
        Producto producto = new Producto(1,"Ron Caldas",35,500,"licor");
        Mercado mercado = new Mercado(35);


   



    }
}
